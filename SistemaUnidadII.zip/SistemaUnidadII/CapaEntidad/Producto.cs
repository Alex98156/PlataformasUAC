﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Runtime.Serialization;

namespace CapaEntidad
{
    [DataContract]

    public class Producto
    {

        [DataMember]
        public string _CodProducto
        { get; set; }

        [DataMember]
        public string _Nombre
        { get; set; }

        [DataMember]
        public string _UnidadMedia
        { get; set; }

        [DataMember]
        public double _Precio
        { get; set; }

        [DataMember]
        public int _Stock
        { get; set; }

        [DataMember]
        public string _CodCategoria
        { get; set; }

    }
}
