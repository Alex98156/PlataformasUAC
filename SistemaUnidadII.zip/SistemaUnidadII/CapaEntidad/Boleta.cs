﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Runtime.Serialization;

namespace CapaEntidad
{

    [DataContract]

    public class Boleta
    {

        [DataMember]
        public string _UsuarioVendedor
        { get; set; }

        [DataMember]
        public string _CodCliente
        { get; set; }

    }
}
