﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

using CapaDatos;
using System.Data;

using System.Data;
using System.Data.SqlClient;

namespace CapaLogica
{
    public class BoletaBL : Interface.IBoleta
    {
        private Datos datos = new DatosSQL();

        public DataTable Listar(Boleta boleta)
        {
            return datos.TraerDataTable("spGenerarBoleta",boleta._UsuarioVendedor,boleta._CodCliente);
        }
    }
}
