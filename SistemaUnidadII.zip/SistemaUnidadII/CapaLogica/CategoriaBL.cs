﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

using CapaDatos;
using System.Data;

using System.Data;
using System.Data.SqlClient;

namespace CapaLogica
{
    public class CategoriaBL : Interface.ICategoria
    {
        private Datos datos = new DatosSQL();

        private string mensaje;
        public string Mensaje
        {
            get { return mensaje; }
        }

        public bool Actualizar(Categoria categoria)
        {
            DataRow fila = datos.TraerDataRow("spActualizarCategoria", categoria._CodCategoria,categoria._Nombre,categoria._CategoriaPadre);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return true;
            else return false;
        }

        public bool Agregar(Categoria categoria)
        {
            DataRow fila = datos.TraerDataRow("spAgregarCategoria", categoria._CodCategoria, categoria._Nombre, categoria._CategoriaPadre);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return true;
            else return false;
        }

        public DataSet Buscar(string texto, string criterio)
        {
            return datos.TraerDataSet("spBuscarCategoria", texto, criterio);
        }

        public string Eliminar(string categoria)
        {
            DataRow fila = datos.TraerDataRow("spEliminarCategoria", categoria);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return "true";
            else return "false";
        }

        public DataSet Listar()
        {
            return datos.TraerDataSet("spListarCategoria");
        }
    }
}
