﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

using CapaDatos;
using CapaLogica.Interface;

namespace CapaLogica
{
    public class VendedorBL : Interface.IVendedor
    {

        private Datos datos = new DatosSQL();
        private string mensaje;

        public string Mensaje
        {
            get { return mensaje; }
                
        }

        public bool Actualizar(Vendedor vendedor)
        {
            DataRow fila = datos.TraerDataRow("spActualizarVendedor", vendedor.CodVendedor, vendedor.Apellidos, vendedor.Nombres);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return true;
            else return false;
        }

        public bool ActualizarContrasena(Vendedor vendedor)
        {
            DataRow fila = datos.TraerDataRow("spActualizarContrasenaVendedor",vendedor.Usuario,vendedor.Contrasena,vendedor._ContrasenaNueva);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return true;
            else return false;
        }

        public bool Agregar(Vendedor vendedor)
        {
            DataRow fila = datos.TraerDataRow("spAgregarVendedor", vendedor.CodVendedor, vendedor.Apellidos, vendedor.Nombres, vendedor.Usuario, vendedor.Contrasena);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return true;
            else return false;
        }

        public DataSet Buscar(string texto, string criterio)
        {
            return datos.TraerDataSet("spBuscarVendedor", texto, criterio);
        }

        public string Eliminar(string CodVendedor)
        {
            DataRow fila = datos.TraerDataRow("spEliminarVendedor", CodVendedor);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return "true";
            else return "false";
        }

        public DataSet Listar()
        {
            return datos.TraerDataSet("spListarVendedor");
        }

        public bool Login(Vendedor vendedor)
        {
            DataRow fila = datos.TraerDataRow("spLoginVendedor", vendedor.Usuario, vendedor.Contrasena);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return true;
            else return false;
        }

    }
}
