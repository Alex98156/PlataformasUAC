﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CapaEntidad;
using System.Data;

namespace CapaLogica.Interface
{
    interface IUsuario
    {
        DataSet Listar();

        bool Login(Usuario usuario);

        bool Agregar(Usuario usuario);

        string Eliminar(string CodCliente);

        bool Actualizar(Usuario usuario);

        bool ActualizarContrasena(Usuario usuario);

        DataSet Buscar(string texto, string criterio);
    }
}
