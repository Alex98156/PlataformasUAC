﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CapaEntidad;
using System.Data;

namespace CapaLogica.Interface
{
    interface IBoleta
    {

        DataTable Listar(Boleta boleta);

    }
}
