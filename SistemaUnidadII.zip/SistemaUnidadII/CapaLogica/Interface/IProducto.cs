﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CapaEntidad;
using System.Data;

namespace CapaLogica.Interface
{
    interface IProducto
    {
        DataSet Listar();

        bool Agregar(Producto producto);

        string Eliminar(string producto);

        bool Actualizar(Producto producto);

        DataSet Buscar(string texto, string criterio);
    }
}
