﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CapaEntidad;
using System.Data;

namespace CapaLogica.Interface
{
    interface IVendedor
    {
        DataSet Listar();

        bool Login(Vendedor vendedor);

        bool Agregar(Vendedor vendedor);

        string Eliminar(string CodVendedor);

        bool Actualizar(Vendedor vendedor);

        bool ActualizarContrasena(Vendedor vendedor);

        DataSet Buscar(string texto, string criterio);
    }
}
