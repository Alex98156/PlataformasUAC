﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

using CapaDatos;
using System.Data;

using System.Data;
using System.Data.SqlClient;

namespace CapaLogica
{
    public class UsuarioBL : Interface.IUsuario
    {

        private Datos datos = new DatosSQL();

        private string mensaje;
        private string contranueva;

        public string Mensaje
        {
            get { return mensaje; }
        }
        public string ContraNueva
        {
            get { return contranueva; }
        }

        public bool Actualizar(Usuario usuario)
        {
            DataRow fila = datos.TraerDataRow("spActualizarCliente", usuario._CodCliente, usuario._Apellidos,usuario._Nombres);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return true;
            else return false;
        }

        public bool ActualizarContrasena(Usuario usuario)
        {
            DataRow fila = datos.TraerDataRow("spActualizarContrasenaCliente", usuario._Usuario, usuario._Contrasena, usuario._ContrasenaNueva);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return true;
            else return false;
        }

        public bool Agregar(Usuario usuario)
        {
            DataRow fila = datos.TraerDataRow("spAgregarCliente",usuario._CodCliente,usuario._Apellidos,usuario._Nombres,usuario._Direccion,usuario._Usuario,usuario._Contrasena);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return true;
            else return false;
        }

        public DataSet Buscar(string texto, string criterio)
        {
            return datos.TraerDataSet("spBuscarCliente", texto, criterio);
        }

        public string Eliminar(string CodCliente)
        {
            DataRow fila = datos.TraerDataRow("spEliminarCliente", CodCliente);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return "true";
            else return "false";
        }

        public DataSet Listar()
        {
            return datos.TraerDataSet("spListarCliente");
        }

        public bool Login(Usuario usuario)
        {
            DataRow fila = datos.TraerDataRow("spLoginCliente",usuario._Usuario,usuario._Contrasena);
            mensaje = fila["Mensaje"].ToString();
            byte codError = Convert.ToByte(fila["CodError"]);
            if (codError == 0) return true;
            else return false;
        }
    }
}
