﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaWeb
{
    public partial class Vendedor : System.Web.UI.Page
    {

        private ServiceReference2.wsVendedorSoapClient servicio = new ServiceReference2.wsVendedorSoapClient();

        private void Listar()
        {
            gvVendedor.DataSource = servicio.Listar();
            gvVendedor.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                Listar();
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            string codVendedor = txtCodVendedor.Text.Trim();
            string apellidos = txtApellidos.Text.Trim();
            string nombres = txtNombres.Text.Trim();
            string usuarios = txtUsuario.Text.Trim();
            string contrasena = txtContrasena.Text.Trim();
            if (servicio.Agregar(codVendedor, apellidos, nombres, usuarios, contrasena)[0]!="a")
                Listar();
        }
    }
}