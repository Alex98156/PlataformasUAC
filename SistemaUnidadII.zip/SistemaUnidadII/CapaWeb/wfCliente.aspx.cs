﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapaWeb
{
    public partial class wfCliente : System.Web.UI.Page
    {

        ServiceReference1.wsUsuarioSoapClient servicio = new ServiceReference1.wsUsuarioSoapClient();

        private string user;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Params["parametro"] != null)
            {
                user = Request.Params["parametro"];
            }
            mvCliente.ActiveViewIndex = 0;
        }

        protected void btnCambiarContrasena_Click(object sender, EventArgs e)
        {
            string[] respuesta = servicio.ActualizarContrasena(user, txtContrasena.Text,txtContrasenaNueva.Text).ToArray();
            string codError = respuesta[0];
            string Mensaje = respuesta[1];
        }

        protected void btnListarProductos_Click(object sender, EventArgs e)
        {
            mvCliente.ActiveViewIndex = 0;
        }

        protected void btnBuscarProductos_Click(object sender, EventArgs e)
        {
            mvCliente.ActiveViewIndex = 1;
        }

        protected void btnCambiarContra_Click(object sender, EventArgs e)
        {
            mvCliente.ActiveViewIndex = 2;
            txtContrasena.Text = user;
        }
    }
}