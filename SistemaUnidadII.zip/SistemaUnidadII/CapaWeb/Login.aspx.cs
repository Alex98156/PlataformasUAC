﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Web.Security;

namespace CapaWeb
{
    public partial class Login : System.Web.UI.Page
    {

        ServiceReference1.wsUsuarioSoapClient servicio = new ServiceReference1.wsUsuarioSoapClient();
        ServiceReference2.wsVendedorSoapClient servicio2 = new ServiceReference2.wsVendedorSoapClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {
            string usuario = LLogin.UserName;
            string contrasena = LLogin.Password;
            if (!CBtipoUsuario.Checked)
            {
                string[] respuesta = servicio.Login(usuario, contrasena).ToArray();
                string codError = respuesta[0];
                string Mensaje = respuesta[1];
                if (codError == "true")
                {
                    FormsAuthentication.RedirectFromLoginPage(usuario, false);
                    Response.Redirect("wfCliente.aspx?Parametro" + Mensaje);

                }
                else { 
                    LLogin.FailureText = Mensaje;
                    }
            }
            else
            {
                string[] respuesta = servicio2.Login(usuario, contrasena).ToArray();
                string codError = respuesta[0];
                string Mensaje = respuesta[1];
                if (codError == "true")
                    Response.Redirect("wfVendedor.aspx?parametro"+Mensaje);
                else
                    LLogin.FailureText = Mensaje;
            }
            
            
            
        }


    }
}