﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

using System.Data;
using iTextSharp.text;
using iTextSharp.text.pdf;

using NPOI.XSSF.UserModel;
using NPOI.SS.UserModel;
using System.IO;

namespace SeguridadFrontEnd
{
    public partial class wfVendedor : System.Web.UI.Page
    {

        private string user1 = " ";

        private ServiceReferenceUsuario.wsUsuarioSoapClient servicio = new ServiceReferenceUsuario.wsUsuarioSoapClient();
        private ServiceReferenceProducto.wsProductoSoapClient servicio2 = new ServiceReferenceProducto.wsProductoSoapClient();
        private ServiceReferenceVendedor.wsVendedorSoapClient servicio3 = new ServiceReferenceVendedor.wsVendedorSoapClient();
        private ServiceReferenceBoleta.wsBoletaSoapClient servicio4 = new ServiceReferenceBoleta.wsBoletaSoapClient();
        private ServiceReferenceCategoria.wsCategoriaSoapClient servicio5 = new ServiceReferenceCategoria.wsCategoriaSoapClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Params["parametro"] != null)
            {
                lbusuario.Text = Request.Params["parametro"];
                user1 = Request.Params["parametro"];
            }
            lbUsuarioVen.Text = user1;
        }

        protected void btnReporte_Click(object sender, EventArgs e)
        {
            mvVendedor.ActiveViewIndex = 0;
        }

        protected void btnProducto_Click(object sender, EventArgs e)
        {
            mvVendedor.ActiveViewIndex = 1;
        }

        protected void btnCategoria_Click(object sender, EventArgs e)
        {
            mvVendedor.ActiveViewIndex = 2;
        }

        protected void btnCambiarContra_Click(object sender, EventArgs e)
        {
            mvVendedor.ActiveViewIndex = 3;
        }

        protected void btnCerrar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void btnCambiarContrasena_Click(object sender, EventArgs e)
        {
            string Usuario = user1;
            string Contrasena = txtContrasena.Text;
            string ContrasenaNueva = txtContrasenaNueva.Text;
            string ContrasenaNueva2 = txtRepitaContrasena.Text;
            if (ContrasenaNueva == ContrasenaNueva2)
            {
                string[] array = servicio3.ActualizarContrasena(Usuario, Contrasena, ContrasenaNueva);
                if (array[0] == "true")
                {
                    Response.Write("<script>alert('" + array[1] + "');</script>");
                }
                else
                {
                    Response.Write("<script>alert('" + array[1] + "');</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('" + "Las contraseñas no son iguales" + "');</script>");
            }
        }

        public void ListarProducto()
        {
            gvProducto.DataSource = servicio2.Listar();
            gvProducto.DataBind();
        }


        protected void btnAgregarP_Click(object sender, EventArgs e)
        {
            string CodP = txtCodProducto.Text;
            string Nombre = txtNombrePro.Text;
            string UnidadMedia = txtUnidadMedia.Text;
            double Precio = Convert.ToDouble(txtPrecio.Text);
            int Stock = int.Parse(txtStock.Text);
            string CodCa = txtCodCategoriaP.Text;

            string[] array = servicio2.Agregar(CodP,Nombre,UnidadMedia,Precio,Stock,CodCa);

            if (array[0] == "true")
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            else
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            ListarProducto();
        }

        protected void btnEliminarP_Click(object sender, EventArgs e)
        {
            string CodP = txtCodProducto.Text;
            string[] array = servicio2.Eliminar(CodP);
            if (array[0] == "true")
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            else
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            ListarProducto();
        }

        protected void btnActualizarP_Click(object sender, EventArgs e)
        {
            string CodP = txtCodProducto.Text;
            string Nombre = txtNombrePro.Text;
            string[] array = servicio2.Actualizar(CodP,Nombre);
            if (array[0] == "true")
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            else
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            ListarProducto();
        }

        protected void btnBuscarP_Click(object sender, EventArgs e)
        {
            string texto = txtBuscarP.Text;
            int criterio = ddlCriterioP.SelectedIndex;

            if (criterio == 0)
            {
                gvProducto.DataSource = servicio2.Buscar(texto, "CodProducto");
                gvProducto.DataBind();
            }
            else if (criterio == 1)
            {
                gvProducto.DataSource = servicio2.Buscar(texto, "Nombre");
                gvProducto.DataBind();
            }
        }

        public void ListarCategoria()
        {
            gvCategoria.DataSource = servicio5.Listar();
            gvCategoria.DataBind();
        }

        protected void btnAgregarC_Click(object sender, EventArgs e)
        {
            string Cod = txtCodCategoria.Text;
            string Nombre = txtNombreC.Text;
            string CP = txtCodPadre.Text;

            string[] array = servicio5.Agregar(Cod, Nombre,CP);
            if (array[0] == "true")
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            else
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            ListarCategoria();
        }

        protected void btnEliminarC_Click(object sender, EventArgs e)
        {
            string Cod = txtCodCategoria.Text;


            string[] array = servicio5.Eliminar(Cod);
            if (array[0] == "true")
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            else
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            ListarCategoria();
        }

        protected void btnActualizarC_Click(object sender, EventArgs e)
        {
            string Cod = txtCodCategoria.Text;
            string Nombre = txtNombreC.Text;
            string CP = txtCodPadre.Text;

            string[] array = servicio5.Actualizar(Cod, Nombre, CP);
            if (array[0] == "true")
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            else
            {
                Response.Write("<script>alert('" + array[1] + "');</script>");
            }
            ListarCategoria();
        }

        protected void btnBuscarC_Click(object sender, EventArgs e)
        {
            string texto = txtBuscarC.Text;
            int criterio = ddlCategoria.SelectedIndex;

            if (criterio == 0)
            {
                gvCategoria.DataSource = servicio5.Buscar(texto, "CodCategoria");
                gvCategoria.DataBind();
            }
            else if (criterio == 1)
            {
                gvCategoria.DataSource = servicio5.Buscar(texto, "Nombre");
                gvCategoria.DataBind();
            }
        }

        protected void btnGenerar_Click(object sender, EventArgs e)
        {
            string UsuarioVen = user1;
            string CodCliente = txtCodCliente.Text;
            gvBoleta.DataSource = servicio4.GeneraBoleta(UsuarioVen, CodCliente);
            gvBoleta.DataBind();
        }

        protected void btnPDF_Click(object sender, EventArgs e)
        {
            string UsuarioVen = user1;
            string CodCliente = txtCodCliente.Text;

            DataTable dt = new DataTable();

            Document document = new Document();
            PdfWriter writer = PdfWriter.GetInstance(document, HttpContext.Current.Response.OutputStream);

            dt = servicio4.GeneraBoleta(UsuarioVen, CodCliente);

            //***************************
            document.Open();

            Font fontTitle = FontFactory.GetFont(FontFactory.COURIER_BOLD, 25);
            Font font9 = FontFactory.GetFont(FontFactory.TIMES, 9);

            PdfPTable table = new PdfPTable(dt.Columns.Count);
            document.Add(new Paragraph(20, "Reporte de Boleta", fontTitle));
            document.Add(new Chunk("\n"));

            float[] widths = new float[dt.Columns.Count];
            for (int i = 0; i < dt.Columns.Count; i++)
                widths[i] = 4f;

            table.SetWidths(widths);
            table.WidthPercentage = 90;

            PdfPCell cell = new PdfPCell(new Phrase("columns"));
            cell.Colspan = dt.Columns.Count;

            foreach (DataColumn c in dt.Columns)
            {
                table.AddCell(new Phrase(c.ColumnName, font9));
            }
            foreach (DataRow r in dt.Rows)
            {
                if (dt.Rows.Count > 0)
                {
                    for (int h = 0; h < dt.Columns.Count; h++)
                    {
                        table.AddCell(new Phrase(r[h].ToString(), font9));
                    }
                }
            }
            document.Add(table);
            document.Close();

            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=ReporteSemana" + ".pdf");
            HttpContext.Current.Response.Write(document);
            Response.Flush();
            Response.End();
            //***************************
        }

        protected void btnExcel_Click(object sender, EventArgs e)
        {
            string UsuarioVen = user1;
            string CodCliente = txtCodCliente.Text;

            DataTable dt = new DataTable();
            dt = servicio4.GeneraBoleta(UsuarioVen, CodCliente);
            Stream s = DataTableToExcel(dt);

            if (s != null)
            {
                MemoryStream ms = s as MemoryStream;
                Response.AddHeader("Content-Disposition", string.Format("attachment;filename=" + HttpUtility.UrlEncode("ReporteSemana") + ".xlsx"));
                Response.ContentType = "application/vnd.ms-excel";
                Response.AddHeader("Content-Length", ms.ToArray().Length.ToString());
                Response.BinaryWrite(ms.ToArray());
                Response.Flush();
                ms.Close();
                ms.Dispose();
            }
            
        }

        public Stream DataTableToExcel(DataTable dt)
        {
            XSSFWorkbook workbook = new XSSFWorkbook();
            MemoryStream ms = new MemoryStream();
            ISheet sheet = workbook.CreateSheet("ReporteSemana");
            XSSFRow headerRow = headerRow = (XSSFRow)sheet.CreateRow(0);
            try
            {
                foreach (DataColumn column in dt.Columns)
                    headerRow.CreateCell(column.Ordinal).SetCellValue(column.ColumnName);
                int rowIndex = 1;
                foreach (DataRow row in dt.Rows)
                {
                    XSSFRow dataRow = (XSSFRow)sheet.CreateRow(rowIndex);
                    foreach (DataColumn column in dt.Columns)
                        dataRow.CreateCell(column.Ordinal).SetCellValue(row[column].ToString());
                    ++rowIndex;
                }
                for (int i = 0; i <= dt.Columns.Count; ++i)
                    sheet.AutoSizeColumn(i);
                workbook.Write(ms);
                ms.Flush();
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                ms.Close();
                sheet = null;
                headerRow = null;
                workbook = null;
            }
            return ms;
        }

    }
}