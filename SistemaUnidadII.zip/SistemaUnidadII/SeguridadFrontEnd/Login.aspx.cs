﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Web.Security;

namespace SeguridadFrontEnd
{
    public partial class Login : System.Web.UI.Page
    {
        ServiceReferenceUsuario.wsUsuarioSoapClient servicio = new ServiceReferenceUsuario.wsUsuarioSoapClient();
        ServiceReferenceVendedor.wsVendedorSoapClient servicio2 = new ServiceReferenceVendedor.wsVendedorSoapClient();

        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnInicio_Click(object sender, EventArgs e)
        {
            string usuario = tbUsuario.Text.Trim();
            string contrasena = tbPassword.Text.Trim();
            if (!CBtipoUsuario.Checked)
            {
                string[] respuesta = servicio.Login(usuario, contrasena).ToArray();
                string codError = respuesta[0];
                string Mensaje = respuesta[1];
                if (codError == "true")
                {
                    Response.Redirect("wfCliente.aspx?parametro=" + usuario);
                }
                else
                {
                    Response.Write("<script>alert('" + Mensaje + "');</script>");
                }
            }
            else
            {
                string[] respuesta = servicio2.Login(usuario, contrasena).ToArray();
                string codError = respuesta[0];
                string Mensaje = respuesta[1];
                if (codError == "true")
                    Response.Redirect("wfVendedor.aspx?parametro=" + usuario);
                else
                    Response.Write("<script>alert('" + Mensaje + "');</script>");
            }
        }
    }
}