﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SeguridadFrontEnd
{
    public partial class wfCliente : System.Web.UI.Page
    {

        private string user1 = " ";

        private ServiceReferenceUsuario.wsUsuarioSoapClient servicio = new ServiceReferenceUsuario.wsUsuarioSoapClient();
        private ServiceReferenceProducto.wsProductoSoapClient servicio2 = new ServiceReferenceProducto.wsProductoSoapClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Params["parametro"] != null)
            {
                user1 = Request.Params["parametro"];
                label1.Text = Request.Params["parametro"];
            }
            else {
                //Response.Redirect("Login.aspx");
            }
        }

        protected void btnListarProductos_Click(object sender, EventArgs e)
        {
            mvCliente.ActiveViewIndex = 0;
            gvCliente.DataSource = servicio2.Listar();
            gvCliente.DataBind();
        }

        protected void btnBuscarProductos_Click(object sender, EventArgs e)
        {
            mvCliente.ActiveViewIndex = 1;
            

        }

        protected void btnCambiarContra_Click(object sender, EventArgs e)
        {
            mvCliente.ActiveViewIndex = 2;
        }

        protected void btnCambiarContrasena_Click(object sender, EventArgs e)
        {
            string Usuario = user1;
            string Contrasena = txtContrasena.Text;
            string ContrasenaNueva = txtContrasenaNueva.Text;
            string ContrasenaNueva2 = txtRepitaContrasena.Text;
            if (ContrasenaNueva == ContrasenaNueva2)
            {
                string[] array = servicio.ActualizarContrasena(Usuario, Contrasena, ContrasenaNueva);
                if (array[0] == "true")
                {
                    Response.Write("<script>alert('" + array[1] + "');</script>");
                }
                else
                {
                    Response.Write("<script>alert('" + array[1] + "');</script>");
                }
            }
            else {
                Response.Write("<script>alert('" + "Las contraseñas no son iguales" + "');</script>");
            }
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {

            string texto = txtBuscar.Text.Trim();
            int criterio = ddlCriterio.SelectedIndex;

            if (criterio == 0)
            {
                gvBuscar.DataSource = servicio2.Buscar(texto, "CodProducto");
                gvBuscar.DataBind();
            }
            else if (criterio == 1)
            {
                gvBuscar.DataSource = servicio2.Buscar(texto, "Nombre");
                gvBuscar.DataBind();
            }

        }

        protected void btnCerrar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }
}