﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using System.Data;
using CapaLogica;
using CapaEntidad;

namespace CapaServicio
{
    /// <summary>
    /// Descripción breve de wsProducto
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class wsProducto : System.Web.Services.WebService
    {

        [WebMethod]
        public DataSet Listar()
        {
            ProductoBL productoBL = new ProductoBL();
            return productoBL.Listar();
        }

        [WebMethod]
        public string[] Agregar(string CodProducto, string Nombre, string UnidadMedida, double Precio, int Stock, string CodCate)
        {
            ProductoBL productoBL = new ProductoBL();
            Producto producto = new Producto();

            producto._CodProducto = CodProducto;
            producto._Nombre = Nombre;
            producto._UnidadMedia = UnidadMedida;
            producto._Precio = Precio;
            producto._Stock = Stock;
            producto._CodCategoria = CodCate;

            bool CodError = productoBL.Agregar(producto);
            string[] array = new string[2];

            if (CodError == true)
                array[0] = "true";
            else
                array[0] = "false";
            array[1] = productoBL.Mensaje;
            return array;
        }


        [WebMethod]
        public string[] Eliminar(string CodProducto)
        {
            ProductoBL productoBL = new ProductoBL();
            Producto producto = new Producto();

            producto._CodCategoria = CodProducto;

            string CodError = productoBL.Eliminar(CodProducto);
            string[] array = new string[2];

            if (CodError == "true") array[0] = "true";
            else array[0] = "false";
            array[1] = productoBL.Mensaje;
            return array;
        }


        [WebMethod]
        public string[] Actualizar(string CodProducto, string Nombre)
        {
            ProductoBL productoBL = new ProductoBL();
            Producto producto = new Producto();

            producto._CodProducto = CodProducto;
            producto._Nombre = Nombre;

            bool CodError = productoBL.Actualizar(producto);
            string[] array = new string[2];

            if (CodError == true) array[0] = "true";
            else array[0] = "false";
            array[1] = productoBL.Mensaje;
            return array;
        }

        [WebMethod]
        public DataSet Buscar(string Texto, string Criterio)
        {
            ProductoBL productoBL = new ProductoBL();
            return productoBL.Buscar(Texto, Criterio);
        }

    }
}
