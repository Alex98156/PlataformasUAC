﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using System.Data;
using CapaLogica;
using CapaEntidad;
using System.Security.Cryptography;
using System.Text;

namespace CapaServicio
{
    /// <summary>
    /// Descripción breve de wsVendedor
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class wsVendedor : System.Web.Services.WebService
    {


        private string generarClaveSHA1(string cadena)
        {

            UTF8Encoding enc = new UTF8Encoding();
            byte[] data = enc.GetBytes(cadena);
            byte[] result;

            SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();

            result = sha.ComputeHash(data);


            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {

                // Convertimos los valores en hexadecimal
                // cuando tiene una cifra hay que rellenarlo con cero
                // para que siempre ocupen dos dígitos.
                if (result[i] < 16)
                {
                    sb.Append("0");
                }
                sb.Append(result[i].ToString("x"));
            }

            //Devolvemos la cadena con el hash en mayúsculas para que quede más chuli :)
            return sb.ToString().ToUpper();
        }



        [WebMethod(Description = "Listar los datos de la tabla vendedor")]
        public DataSet Listar() {
            VendedorBL vendedor = new VendedorBL();
            return vendedor.Listar();
        }

        [WebMethod(Description = "Agregar a un vendedor")]
        public string[] Agregar(string CodVendedor, string Apellidos, string Nombres, string Usuario, string Contrasena)
        {
            Vendedor vendedor = new Vendedor();
            vendedor.CodVendedor = CodVendedor;
            vendedor.Apellidos = Apellidos;
            vendedor.Nombres = Nombres;
            vendedor.Usuario = Usuario;
            vendedor.Contrasena = generarClaveSHA1(Contrasena);
            VendedorBL vendedorBL = new VendedorBL();
            bool CodError = vendedorBL.Agregar(vendedor);
            string[] array = new string[2];

            if (CodError == true)
                array[0] = "true";
            else
                array[0] = "false";
            array[1] = vendedorBL.Mensaje;
            return array;
        }

        [WebMethod]
        public string[] Login(string Usuario, string Contrasena)
        {
            VendedorBL vendedorBL = new VendedorBL();
            Vendedor vendedor = new Vendedor();

            vendedor.Usuario = Usuario;
            vendedor.Contrasena = generarClaveSHA1(Contrasena);

            bool CodError = vendedorBL.Login(vendedor);
            string[] array = new string[2];

            if (CodError == true) array[0] = "true";
            else array[0] = "false";
            array[1] = vendedorBL.Mensaje;
            return array;
        }

        [WebMethod]
        public string[] Eliminar(string CodVendedor)
        {
            VendedorBL vendedorBL = new VendedorBL();
            Vendedor vendedor = new Vendedor();

            vendedor.CodVendedor = CodVendedor;

            string CodError = vendedorBL.Eliminar(CodVendedor);
            string[] array = new string[2];

            if (CodError == "true") array[0] = "true";
            else array[0] = "false";
            array[1] = vendedorBL.Mensaje;
            return array;
        }

        [WebMethod]
        public string[] Actualizar(string CodVendedor, string Apellidos, string Nombres)
        {
            VendedorBL vendedorBL = new VendedorBL();
            Vendedor vendedor = new Vendedor();

            vendedor.CodVendedor = CodVendedor;
            vendedor.Apellidos = Apellidos;
            vendedor.Nombres = Nombres;

            bool CodError = vendedorBL.Actualizar(vendedor);
            string[] array = new string[2];

            if (CodError == true) array[0] = "true";
            else array[0] = "false";
            array[1] = vendedorBL.Mensaje;
            return array;
        }

        [WebMethod]
        public string[] ActualizarContrasena(string Usuario, string Contrasena, string ContraNueva)
        {
            VendedorBL vendedorBL = new VendedorBL();
            Vendedor vendedor = new Vendedor();

            vendedor.Usuario = Usuario;
            vendedor.Contrasena = generarClaveSHA1(Contrasena);
            vendedor._ContrasenaNueva = generarClaveSHA1(ContraNueva);

            bool CodError = vendedorBL.ActualizarContrasena(vendedor);
            string[] array = new string[2];

            if (CodError == true) array[0] = "true";
            else array[0] = "false";
            array[1] = vendedorBL.Mensaje;
            return array;
        }

        [WebMethod]
        public DataSet Buscar(string Texto, string Criterio)
        {
            VendedorBL vendedorBL = new VendedorBL();
            return vendedorBL.Buscar(Texto, Criterio);
        }

    }
}
