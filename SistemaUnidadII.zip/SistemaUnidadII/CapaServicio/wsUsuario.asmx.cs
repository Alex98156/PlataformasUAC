﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using System.Data;
using CapaLogica;
using CapaEntidad;
using System.Security.Cryptography;
using System.Text;


namespace CapaServicio
{
    /// <summary>
    /// Descripción breve de wsUsuario
    /// </summary>
    /// 
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class wsUsuario : System.Web.Services.WebService
    {


        private string generarClaveSHA1(string cadena)
        {

            UTF8Encoding enc = new UTF8Encoding();
            byte[] data = enc.GetBytes(cadena);
            byte[] result;

            SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();

            result = sha.ComputeHash(data);


            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {

                // Convertimos los valores en hexadecimal
                // cuando tiene una cifra hay que rellenarlo con cero
                // para que siempre ocupen dos dígitos.
                if (result[i] < 16)
                {
                    sb.Append("0");
                }
                sb.Append(result[i].ToString("x"));
            }

            //Devolvemos la cadena con el hash en mayúsculas para que quede más chuli :)
            return sb.ToString().ToUpper();
        }



        [WebMethod]
        public string[] Login(string Usuario, string Contrasena)
        {
            UsuarioBL usuarioBL = new UsuarioBL();
            Usuario usuario = new Usuario();
            usuario._Usuario = Usuario;
            usuario._Contrasena = generarClaveSHA1(Contrasena);

            bool CodError = usuarioBL.Login(usuario);
            string[] array = new string[2];

            if (CodError == true) array[0] = "true";
            else array[0] = "false";
            array[1] = usuarioBL.Mensaje;
            return array;
        }

        [WebMethod]
        public string[] Agregar(string CodCliente, string Apellidos, string Nombres, string Direccion, string Usuario, string Contrasena)
        {
            UsuarioBL usuarioBL = new UsuarioBL();
            Usuario usuario = new Usuario();
            usuario._CodCliente = CodCliente;
            usuario._Apellidos = Apellidos;
            usuario._Nombres = Nombres;
            usuario._Direccion = Direccion;
            usuario._Usuario = Usuario;
            usuario._Contrasena = generarClaveSHA1(Contrasena);

            bool CodError = usuarioBL.Agregar(usuario);
            string[] array = new string[2];

            if (CodError == true)
                array[0] = "true";
            else
                array[0] = "false";
            array[1] = usuarioBL.Mensaje;
            return array;
        }

        [WebMethod]
        public string[] Actualizar(string CodCliente, string Apellidos, string Nombres)
        {
            UsuarioBL usuarioBL = new UsuarioBL();
            Usuario usuario = new Usuario();
            usuario._CodCliente = CodCliente;
            usuario._Apellidos = Apellidos;
            usuario._Nombres = Nombres;

            bool CodError = usuarioBL.Actualizar(usuario);
            string[] array = new string[2];

            if (CodError == true) array[0] = "true";
            else array[0] = "false";
            array[1] = usuarioBL.Mensaje;
            return array;
        }

        [WebMethod]
        public string[] Eliminar(string CodCliente)
        {
            UsuarioBL usuarioBL = new UsuarioBL();
            Usuario usuario = new Usuario();
            usuario._CodCliente = CodCliente;

            string CodError = usuarioBL.Eliminar(CodCliente);
            string[] array = new string[2];

            if (CodError == "true") array[0] = "true";
            else array[0] = "false";
            array[1] = usuarioBL.Mensaje;
            return array;
        }


        [WebMethod]
        public string[] ActualizarContrasena(string Usuario, string Contrasena, string ContraNueva)
        {
            UsuarioBL usuarioBL = new UsuarioBL();
            Usuario usuario = new Usuario();
            usuario._Usuario = Usuario;
            usuario._Contrasena = generarClaveSHA1(Contrasena);
            usuario._ContrasenaNueva = generarClaveSHA1(ContraNueva);

            bool CodError = usuarioBL.ActualizarContrasena(usuario);
            string[] array = new string[2];

            if (CodError == true) array[0] = "true";
            else array[0] = "false";
            array[1] = usuarioBL.Mensaje;
            return array;
        }

        [WebMethod]
        public DataSet Listar()
        {
            UsuarioBL usuario = new UsuarioBL();
            return usuario.Listar();
        }

        [WebMethod]
        public DataSet Buscar(string Texto,string Criterio)
        {
            UsuarioBL usuarioBL = new UsuarioBL();
            return usuarioBL.Buscar(Texto,Criterio);
        }
    }
}
