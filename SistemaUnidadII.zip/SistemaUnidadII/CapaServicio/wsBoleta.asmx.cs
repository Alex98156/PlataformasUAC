﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using System.Data;
using CapaLogica;
using CapaEntidad;
using System.Security.Cryptography;
using System.Text;


namespace CapaServicio
{
    /// <summary>
    /// Descripción breve de wsBoleta
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class wsBoleta : System.Web.Services.WebService
    {

        [WebMethod]
        public DataTable GeneraBoleta(string UsuarioVendedor,string CodC)
        {
            BoletaBL boletaBL = new BoletaBL();
            Boleta boleta = new Boleta();

            boleta._UsuarioVendedor = UsuarioVendedor;
            boleta._CodCliente = CodC;

            return boletaBL.Listar(boleta);
        }
    }
}
