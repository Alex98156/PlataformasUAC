﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using System.Data;
using CapaLogica;
using CapaEntidad;
using System.Text;

namespace CapaServicio
{
    /// <summary>
    /// Descripción breve de wsCategoria
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class wsCategoria : System.Web.Services.WebService
    {

        [WebMethod]
        public DataSet Listar()
        {
            CategoriaBL categoriaBL = new CategoriaBL();
            return categoriaBL.Listar();
        }

        [WebMethod]
        public string[] Agregar(string CodCategoria,string Nombre, string CatPadre)
        {
            CategoriaBL categoriaBL = new CategoriaBL();
            Categoria categoria = new Categoria();

            categoria._CodCategoria = CodCategoria;
            categoria._Nombre = Nombre;
            categoria._CategoriaPadre = CatPadre;

            bool CodError = categoriaBL.Agregar(categoria);
            string[] array = new string[2];

            if (CodError == true)
                array[0] = "true";
            else
                array[0] = "false";
            array[1] = categoriaBL.Mensaje;
            return array;
        }


        [WebMethod]
        public string[] Eliminar(string CodCategoria)
        {
            CategoriaBL categoriaBL = new CategoriaBL();
            Categoria categoria = new Categoria();

            categoria._CodCategoria = CodCategoria;

            string CodError = categoriaBL.Eliminar(CodCategoria);
            string[] array = new string[2];

            if (CodError == "true") array[0] = "true";
            else array[0] = "false";
            array[1] = categoriaBL.Mensaje;
            return array;
        }


        [WebMethod]
        public string[] Actualizar(string CodCategoria, string Nombre, string CatPadre)
        {
            CategoriaBL categoriaBL = new CategoriaBL();
            Categoria categoria = new Categoria();

            categoria._CodCategoria = CodCategoria;
            categoria._Nombre = Nombre;
            categoria._CategoriaPadre = CatPadre;

            bool CodError = categoriaBL.Actualizar(categoria);
            string[] array = new string[2];

            if (CodError == true) array[0] = "true";
            else array[0] = "false";
            array[1] = categoriaBL.Mensaje;
            return array;
        }

        [WebMethod]
        public DataSet Buscar(string Texto, string Criterio)
        {
            CategoriaBL categoriaBL = new CategoriaBL();
            return categoriaBL.Buscar(Texto, Criterio);
        }

    }
}
